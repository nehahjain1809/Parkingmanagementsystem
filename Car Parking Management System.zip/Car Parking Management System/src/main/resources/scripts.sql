CREATE DATABASE PARKING_DB;

USE PARKING_DB;

drop table user;
drop table car;
drop table apartment;
drop table user_apartment;
drop table parking;
drop table apartment_parking;
drop table access_request;
drop table register_request;

create table user (
	user_id int,
	user_name varchar(100),
	email varchar(100),
	role varchar(100),
	password varchar(32),
	contact int,
	upd_time datetime,
	upd_time_end datetime
);

create table apartment (
	apartment_id int,
	apartment_number varchar(100)
);

create table user_apartment (
	user_id int,
	apartment_id int,
	upd_time datetime,
	upd_time_end datetime
);

create table car (
	car_id int,
	car_number varchar(100),
	car_owner int,,
	upd_time datetime,
	upd_time_end datetime
);

create table complaint (
	complaint_id int,
    user_from int,
    user_to int,
    car_id int,
    complaint_status varchar(100),
    complaint_charges float,
    upd_time datetime,
    upd_time_end datetime
);

--SELECT comp.complaint_id, u1.email as from_user, u2.email as against_user, c1.car_number, comp.complaint_status, comp.complaint_charges, comp.upd_time from complaint comp join user u1 on comp.user_from = u1.user_id join user u2 on comp.user_to = u2.user_id join car c1 on comp.car_id=c1.car_id WHERE (u1.user_id=? OR u2.user_id=?) and comp.upd_time_end=?
--SELECT * from register_request as req join user u1 on req.user_id = u1.user_id join apartment a1 on req.apartment_id = a1.apartment_id join car c1 on req.car_id = c1.car_id where req.user_id=? and req.upd_time_end=?
create table parking (
	parking_id int,
	parking_number varchar(100),
	parking_type varchar(100),
	parking_status boolean,
	price float,
	upd_time datetime,
	upd_time_end datetime
);


create table apartment_parking (
	apartment_id int,
	parking_id int,
	upd_time datetime,
	upd_time_end datetime
);

create table access_request (
	request_id int,
	username varchar(100),
	email varchar(100),
	status varchar(100),
	apartment varchar(100),
	upd_time datetime,
	upd_time_end datetime
);

create table register_request (
	request_id int,
	user_id int,
	apartment_id int,
	status varchar(100),
	car_id int,
	parking_id int,
	upd_time datetime,
	upd_time_end datetime
);
