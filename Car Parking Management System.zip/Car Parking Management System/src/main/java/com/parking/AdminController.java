package com.parking;

import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.parking.dao.ParkingHome;
import com.parking.domain.AccessRequest;
import com.parking.domain.Apartment;
import com.parking.domain.RegisterRequest;
import com.parking.domain.Status;
import com.parking.domain.User;

@Controller
@RequestMapping(value="/admin/*")
public class AdminController {
	
	@Resource
	private ParkingHome parkingHome;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		return "admin-dashboard";
	}

	@RequestMapping(value="action/update", method = RequestMethod.GET)
	public String handleRegisterVehicleForm(HttpServletRequest request) {
		
		return "edit-parking-slots";
	}
	
	@RequestMapping(value="action/approveaccess", method = RequestMethod.GET)
	public String handleGetFileComplaintForm(HttpServletRequest request) {
		List<AccessRequest> requestsToApprove = parkingHome.fetchPendingAccessRequests();
		request.setAttribute("requestsToApprove", requestsToApprove);
		return "edit-access-requests";
	}
	
	@RequestMapping(value="action/approveregister", method = RequestMethod.GET)
	public String handleGuestServicesForm(HttpServletRequest request) {
		
		List<RegisterRequest> registerRequestsToApprove = parkingHome.fetchPendingRegisterRequests();
		request.setAttribute("registerRequestsToApprove", registerRequestsToApprove);
		return "edit-register-requests";
	}
	
	@RequestMapping(value="action/editaccessrequest", method = RequestMethod.POST)
	public String handleEditAccessRequestForm(HttpServletRequest request) {
		int requestId = Integer.parseInt(request.getParameter("requestId"));
		AccessRequest requestToApprove = parkingHome.fetchPendingAccessRequest(requestId);
		Status status = Status.valueOf(request.getParameter("options"));
		requestToApprove.setStatus(status);
		parkingHome.persistAccessRequest(requestToApprove);
		if (status == Status.APPROVED) {
			requestToApprove.setStatus(Status.APPROVED);
			Apartment apartment = parkingHome.fetchApartment(requestToApprove.getApartmentNumber());
			User user = new User(requestToApprove, apartment);
			parkingHome.persistUser(user);
			parkingHome.persistUserApartment(user.getUserId(), apartment.getApartmentId(), new Date());
		}
		return "admin-action-success";
	}
	
	@RequestMapping(value="action/editregisterrequest", method = RequestMethod.POST)
	public String handleEditRegisterRequestForm(HttpServletRequest request) {
		// Approve or reject a register request
		int requestId = Integer.parseInt(request.getParameter("request_id"));
		Status status = Status.valueOf(request.getParameter("request_status"));
		RegisterRequest registerRequest = parkingHome.fetchPendingRegisterRequest(requestId);
		registerRequest.setStatus(status);
		registerRequest.setUpdateTime(new Date());
		parkingHome.persistRegisterRequest(registerRequest);

		// Accordingly assign a parking to a user/apartment
		if (status == Status.APPROVED) {
			parkingHome.persistApartmentParking(registerRequest.getApartmentNumber(), registerRequest.getParkingNumber(), new Date());
		}
		return "admin-action-success";
	}
	
	@RequestMapping(value="action/editparkingslots", method = RequestMethod.POST)
	public String handleEditParkingForm(HttpServletRequest request) {
		return "admin-action-success";
	}
}
