package com.parking.domain;

public class Car {

	private int carId;

	private String carNumber;
	
	private String owner;
	
	public Car() {
	}

	public Car(int carId, String carNumber, String owner) {
		this.carId = carId;
		this.carNumber = carNumber;
		this.owner = owner;
	}

	public String getCarNumber() {
		return carNumber;
	}

	public void setCarNumber(String carNumber) {
		this.carNumber = carNumber;
	}

	public int getCarId() {
		return carId;
	}

	public void setCarId(int carId) {
		this.carId = carId;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}
}
