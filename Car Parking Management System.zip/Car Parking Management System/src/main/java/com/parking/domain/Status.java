package com.parking.domain;

public enum Status {

	APPROVED, CANCELLED, PENDING;
}
