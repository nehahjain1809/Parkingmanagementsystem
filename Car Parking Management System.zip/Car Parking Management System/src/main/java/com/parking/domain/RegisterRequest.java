package com.parking.domain;

import java.util.Date;

public class RegisterRequest {

	private int requestId;
	
	private String email;
	
	private String apartmentNumber;
	
	private String carNumber;
	
	private String parkingNumber;
	
	private Status status;

	private Date updateTime;

	public RegisterRequest(int requestId, String email, String apartmentNumber, String carNumber, String parkingNumber, Status status, Date updateTime) {
		this.requestId = requestId;
		this.email = email;
		this.apartmentNumber = apartmentNumber;
		this.carNumber = carNumber;
		this.parkingNumber = parkingNumber;
		this.status = status;
		this.setUpdateTime(updateTime);
	}

	public int getRequestId() {
		return requestId;
	}

	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}

	public String getUserEmail() {
		return email;
	}

	public void setUserEmail(String email) {
		this.email = email;
	}

	public String getApartmentNumber() {
		return apartmentNumber;
	}

	public void setApartmentNumber(String apartmentNumber) {
		this.apartmentNumber = apartmentNumber;
	}

	public String getCarNumber() {
		return carNumber;
	}

	public void setCarNumber(String carNumber) {
		this.carNumber = carNumber;
	}

	public String getParkingNumber() {
		return parkingNumber;
	}

	public void setParkingNumber(String parkingNumber) {
		this.parkingNumber = parkingNumber;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("RegisterRequest [requestId=").append(requestId).append(", email=").append(email)
				.append(", apartmentNumber=").append(apartmentNumber).append(", carNumber=").append(carNumber)
				.append(", parkingNumber=").append(parkingNumber).append(", status=").append(status).append("]");
		return builder.toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((apartmentNumber == null) ? 0 : apartmentNumber.hashCode());
		result = prime * result + ((carNumber == null) ? 0 : carNumber.hashCode());
		result = prime * result + ((parkingNumber == null) ? 0 : parkingNumber.hashCode());
		result = prime * result + requestId;
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof RegisterRequest)) {
			return false;
		}
		RegisterRequest other = (RegisterRequest) obj;
		if (apartmentNumber == null) {
			if (other.apartmentNumber != null) {
				return false;
			}
		} else if (!apartmentNumber.equals(other.apartmentNumber)) {
			return false;
		}
		if (carNumber == null) {
			if (other.carNumber != null) {
				return false;
			}
		} else if (!carNumber.equals(other.carNumber)) {
			return false;
		}
		if (parkingNumber == null) {
			if (other.parkingNumber != null) {
				return false;
			}
		} else if (!parkingNumber.equals(other.parkingNumber)) {
			return false;
		}
		if (requestId != other.requestId) {
			return false;
		}
		if (status == null) {
			if (other.status != null) {
				return false;
			}
		} else if (!status.equals(other.status)) {
			return false;
		}
		if (email == null) {
			if (other.email != null) {
				return false;
			}
		} else if (!email.equals(other.email)) {
			return false;
		}
		return true;
	}
}
