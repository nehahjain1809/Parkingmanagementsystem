package com.parking.domain;

public enum ComplaintStatus {
	ACTIONED, PENDING, REJECTED;
}
