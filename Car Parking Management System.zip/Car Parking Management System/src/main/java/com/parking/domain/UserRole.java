package com.parking.domain;

public enum UserRole {
	APARTMENT_OWNER, ADMIN;
}
