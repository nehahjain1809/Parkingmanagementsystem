package com.parking.domain;

import java.util.ArrayList;
import java.util.List;

public class User {
	
	private int userId;

	private String name;

	private String email;
	
	private String password;
	
	private UserRole userRole;
	
	private List<Apartment> apartments;
	
	private int contact;

	public User(int userId, String name, String email, String password, UserRole userRole, List<Apartment> apartments, int contact) {
		this.userId = userId;
		this.name = name;
		this.email = email;
		this.password = password;
		this.userRole = userRole;
		this.apartments = apartments;
		this.contact = contact;
	}

	public User(AccessRequest accessRequest, Apartment apartment) {
		this.userId = 0;
		this.name = accessRequest.getUserName();
		this.email = accessRequest.getEmail();
		this.userRole = UserRole.APARTMENT_OWNER;
		this.apartments = new ArrayList<>();
		apartments.add(apartment);
		this.contact = accessRequest.getContact();
		this.password = accessRequest.getPassword();
	}
	public int getUserId() {
		return userId;
	}

	public void setUserId(int id) {
		this.userId = id;
	}

	public int getContact() {
		return contact;
	}

	public void setContact(int contact) {
		this.contact = contact;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public UserRole getUserRole() {
		return userRole;
	}

	public void setUserRole(UserRole userRole) {
		this.userRole = userRole;
	}

	public List<Apartment> getApartments() {
		return apartments;
	}

	public void setApartment(List<Apartment> apartments) {
		this.apartments = apartments;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("User [name=").append(name).append(", email=").append(email).append(", password=")
				.append(password).append(", userRole=").append(userRole).append(", apartments=").append(apartments)
				.append(", contact=").append(contact).append("]");
		return builder.toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((apartments == null) ? 0 : apartments.hashCode());
		result = prime * result + contact;
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		result = prime * result + ((userRole == null) ? 0 : userRole.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof User)) {
			return false;
		}
		User other = (User) obj;
		if (apartments == null) {
			if (other.apartments != null) {
				return false;
			}
		} else if (!apartments.equals(other.apartments)) {
			return false;
		}
		if (contact != other.contact) {
			return false;
		}
		if (email == null) {
			if (other.email != null) {
				return false;
			}
		} else if (!email.equals(other.email)) {
			return false;
		}
		if (name == null) {
			if (other.name != null) {
				return false;
			}
		} else if (!name.equals(other.name)) {
			return false;
		}
		if (password == null) {
			if (other.password != null) {
				return false;
			}
		} else if (!password.equals(other.password)) {
			return false;
		}
		if (userRole != other.userRole) {
			return false;
		}
		return true;
	}

}
