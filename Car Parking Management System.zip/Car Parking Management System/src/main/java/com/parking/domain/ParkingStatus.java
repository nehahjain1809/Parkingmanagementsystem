package com.parking.domain;

public enum ParkingStatus {
	ASSIGNED, AVAILABLE, ON_AUCTION;
}
