package com.parking.domain;

import java.util.Date;

public class Parking {

	private int parkingId;
	
	private ParkingType parkingType;
	
	private String parkingNumber;
	
	private ParkingStatus parkingStatus;

	private float price;

	private Date updateTime;

	public Parking(int parkingId, ParkingType parkingType, String parkingNumber, ParkingStatus parkingStatus,
			float price, Date updateTime) {
		this.parkingId = parkingId;
		this.parkingType = parkingType;
		this.parkingNumber = parkingNumber;
		this.parkingStatus = parkingStatus;
		this.price = price;
		this.updateTime = updateTime;
	}

	public Parking() {
	}

	public int getParkingId() {
		return parkingId;
	}

	public void setParkingId(int parkingId) {
		this.parkingId = parkingId;
	}

	public ParkingType getParkingType() {
		return parkingType;
	}

	public void setParkingType(ParkingType parkingType) {
		this.parkingType = parkingType;
	}

	public String getParkingNumber() {
		return parkingNumber;
	}

	public void setParkingNumber(String parkingNumber) {
		this.parkingNumber = parkingNumber;
	}

	public ParkingStatus getParkingStatus() {
		return parkingStatus;
	}

	public void setParkingStatus(ParkingStatus parkingStatus) {
		this.parkingStatus = parkingStatus;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	
	

}
