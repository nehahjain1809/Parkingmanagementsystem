package com.parking.domain;

public enum ParkingType {
	BASEMENT, GARRAGE, OPEN;
}
