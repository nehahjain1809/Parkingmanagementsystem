package com.parking.domain;

public class Apartment {

	private int apartmentId;

	private String apartmentNumber;

	public int getApartmentId() {
		return apartmentId;
	}

	public void setApartmentId(int apartmentId) {
		this.apartmentId = apartmentId;
	}

	public String getApartmentNumber() {
		return apartmentNumber;
	}

	public void setApartmentNumber(String apartmentNumber) {
		this.apartmentNumber = apartmentNumber;
	}

	public Apartment(int apartmentId, String apartmentNumber) {
		this.apartmentId = apartmentId;
		this.apartmentNumber = apartmentNumber;
	}

	public Apartment() {
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Apartment [apartmentId=").append(apartmentId).append(", apartmentNumber=")
				.append(apartmentNumber).append("]");
		return builder.toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + apartmentId;
		result = prime * result + ((apartmentNumber == null) ? 0 : apartmentNumber.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Apartment)) {
			return false;
		}
		Apartment other = (Apartment) obj;
		if (apartmentId != other.apartmentId) {
			return false;
		}
		if (apartmentNumber == null) {
			if (other.apartmentNumber != null) {
				return false;
			}
		} else if (!apartmentNumber.equals(other.apartmentNumber)) {
			return false;
		}
		return true;
	}
}
