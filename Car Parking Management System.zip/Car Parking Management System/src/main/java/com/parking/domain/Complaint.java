package com.parking.domain;

import java.util.Date;

public class Complaint {

	private int complaintId;

	private String complaintFrom;

	private String complaintAgainst;

	private String carNumber;

	private ComplaintStatus complaintStatus;

	private float complaintCharges;

	private Date updateTime;

	private Parking parking;

	public Complaint() {
	}

	public Complaint(int complaintId, String complaintFrom, String complaintAgainst, String carNumber,
			ComplaintStatus complaintStatus, float complaintCharges, Date updateTime, Parking parking) {
		this.complaintId = complaintId;
		this.complaintFrom = complaintFrom;
		this.complaintAgainst = complaintAgainst;
		this.carNumber = carNumber;
		this.complaintStatus = complaintStatus;
		this.complaintCharges = complaintCharges;
		this.updateTime = updateTime;
		this.parking = parking;
	}

	public int getComplaintId() {
		return complaintId;
	}

	public void setComplaintId(int complaintId) {
		this.complaintId = complaintId;
	}

	public String getComplaintFrom() {
		return complaintFrom;
	}

	public void setComplaintFrom(String complaintFrom) {
		this.complaintFrom = complaintFrom;
	}

	public String getComplaintAgainst() {
		return complaintAgainst;
	}

	public void setComplaintAgainst(String complaintAgainst) {
		this.complaintAgainst = complaintAgainst;
	}

	public String getCarNumber() {
		return carNumber;
	}

	public void setCarNumber(String carNumber) {
		this.carNumber = carNumber;
	}

	public ComplaintStatus getComplaintStatus() {
		return complaintStatus;
	}

	public void setComplaintStatus(ComplaintStatus complaintStatus) {
		this.complaintStatus = complaintStatus;
	}

	public float getComplaintCharges() {
		return complaintCharges;
	}

	public void setComplaintCharges(float complaintCharges) {
		this.complaintCharges = complaintCharges;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Parking getParking() {
		return parking;
	}

	public void setParking(Parking parking) {
		this.parking = parking;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Complaint [complaintId=").append(complaintId).append(", complaintFrom=")
				.append(complaintFrom).append(", complaintAgainst=").append(complaintAgainst).append(", carNumber=")
				.append(carNumber).append(", complaintStatus=").append(complaintStatus).append(", complaintCharges=")
				.append(complaintCharges).append(", updateTime=").append(updateTime).append("]");
		return builder.toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((carNumber == null) ? 0 : carNumber.hashCode());
		result = prime * result + ((complaintAgainst == null) ? 0 : complaintAgainst.hashCode());
		result = prime * result + Float.floatToIntBits(complaintCharges);
		result = prime * result + ((complaintFrom == null) ? 0 : complaintFrom.hashCode());
		result = prime * result + complaintId;
		result = prime * result + ((complaintStatus == null) ? 0 : complaintStatus.hashCode());
		result = prime * result + ((updateTime == null) ? 0 : updateTime.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Complaint)) {
			return false;
		}
		Complaint other = (Complaint) obj;
		if (carNumber == null) {
			if (other.carNumber != null) {
				return false;
			}
		} else if (!carNumber.equals(other.carNumber)) {
			return false;
		}
		if (complaintAgainst == null) {
			if (other.complaintAgainst != null) {
				return false;
			}
		} else if (!complaintAgainst.equals(other.complaintAgainst)) {
			return false;
		}
		if (Float.floatToIntBits(complaintCharges) != Float.floatToIntBits(other.complaintCharges)) {
			return false;
		}
		if (complaintFrom == null) {
			if (other.complaintFrom != null) {
				return false;
			}
		} else if (!complaintFrom.equals(other.complaintFrom)) {
			return false;
		}
		if (complaintId != other.complaintId) {
			return false;
		}
		if (complaintStatus != other.complaintStatus) {
			return false;
		}
		if (updateTime == null) {
			if (other.updateTime != null) {
				return false;
			}
		} else if (!updateTime.equals(other.updateTime)) {
			return false;
		}
		return true;
	}

}
