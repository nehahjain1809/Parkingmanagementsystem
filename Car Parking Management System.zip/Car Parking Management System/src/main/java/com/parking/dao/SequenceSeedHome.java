package com.parking.dao;

import java.util.concurrent.atomic.AtomicInteger;

import com.parking.exceptions.DataAccessException;

/**
 * Class that holds sequence seeds for ids of various tables. These seeds are loaded upon app startup and then maintained inside atomic variables
 * This class should be a singleton, to ensure that one consistent copy of the seeds are maintained inside the application!
 */
public class SequenceSeedHome extends AbstractMySqlHome {

	private static SequenceSeedHome sequenceSeedHome = null;

	private AtomicInteger accessRequestSeed;

	private AtomicInteger userSeed;

	private AtomicInteger parkingSeed;

	private AtomicInteger apartmentSeed;

	private AtomicInteger complaintSeed;

	private AtomicInteger registerRequestSeed;
	
	private AtomicInteger carSeed;

	private SequenceSeedHome(String host, String port, String database, String user, String password) {
		super(host, port, database, user, password);
		accessRequestSeed = new AtomicInteger(getTableSeed("access_request", "request_id"));
		registerRequestSeed = new AtomicInteger(getTableSeed("register_request", "request_id"));
		userSeed = new AtomicInteger(getTableSeed("user", "user_id"));
		parkingSeed = new AtomicInteger(getTableSeed("parking", "parking_id"));
		apartmentSeed = new AtomicInteger(getTableSeed("apartment", "apartment_id"));
		complaintSeed = new AtomicInteger(getTableSeed("complaint", "complaint_id"));
		carSeed = new AtomicInteger(getTableSeed("car", "car_id"));
	}

	
	public int getCarSeed() {
		return carSeed.incrementAndGet();
	}

	public int getAccessRequestSeed() {
		return accessRequestSeed.incrementAndGet();
	}

	public int getRegisterRequestSeed() {
		return registerRequestSeed.incrementAndGet();
	}

	public int getUserSeed() {
		return userSeed.incrementAndGet();
	}

	public int getApartmentSeed() {
		return apartmentSeed.incrementAndGet();
	}

	public int getParkingSeed() {
		return parkingSeed.incrementAndGet();
	}

	public int getComplaintSeed() {
		return complaintSeed.incrementAndGet();
	}

	private int getTableSeed(String tableName, String idColumnName) {
		return RowMappers.mapFirstRow(executeQuery("SELECT coalesce(max(" + idColumnName + ")) as " +idColumnName + " FROM " + tableName), RowMappers.getIdMapper(idColumnName));
	}

	public static SequenceSeedHome getInstance(String host, String port, String database, String user, String password) {
		if (sequenceSeedHome != null) {
			return sequenceSeedHome;
		}
		synchronized (SequenceSeedHome.class) {
			if (sequenceSeedHome == null) {
				sequenceSeedHome = new SequenceSeedHome(host, port, database, user, password);
			}
		}
		return sequenceSeedHome;
	}
}
