package com.parking.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.parking.domain.AccessRequest;
import com.parking.domain.Car;
import com.parking.domain.Complaint;
import com.parking.domain.ComplaintStatus;
import com.parking.domain.Parking;
import com.parking.domain.ParkingStatus;
import com.parking.domain.ParkingType;
import com.parking.domain.RegisterRequest;
import com.parking.domain.Status;
import com.parking.domain.User;
import com.parking.domain.UserRole;
import com.parking.exceptions.DataAccessException;

public final class RowMappers {

	private RowMappers() {
	}

	static interface RowMapper<T> {
		T mapRow(ResultSet resultSet, int rowNum) throws SQLException;
	}

	public static <T> List<T> mapAllRows(ResultSet resultSet, RowMapper<T> rowMapper) {
		List<T> result = new ArrayList<>();
		int rowNum = 1;
		try {
			while(resultSet.next()) {
				result.add(rowMapper.mapRow(resultSet, rowNum++));
			}
			resultSet.close();
		} catch (SQLException e) {
			throw new DataAccessException("Failed to process result ", e);
		}
		return result;
	}

	public static <T> T mapFirstRow(ResultSet resultSet, RowMapper<T> rowMapper) {
		try {
			if (resultSet == null || resultSet.isLast()) {
				return null;
			}
			resultSet.next();
			T result = rowMapper.mapRow(resultSet, 1);
			resultSet.close();
			return result;
		} catch (SQLException e) {
			throw new DataAccessException("Failed to process result ", e);
		}
	}

	public static RowMapper<String> USER_PASSWORD_MAPPER = new RowMapper<String>() {
		@Override
		public String mapRow(ResultSet resultSet, int rowNum) throws SQLException {
			return resultSet.getString("password");
		}
	};

	public static RowMapper<User> USER_WITHOUT_PASSWORD_MAPPER = new RowMapper<User>() {
		@Override
		public User mapRow(ResultSet resultSet, int rowNum) throws SQLException {
			return new User(resultSet.getInt("user_id"),
					resultSet.getString("user_name"), resultSet.getString("email"), null, UserRole.valueOf(resultSet.getString("role")), null, resultSet.getInt("contact"));
		}
	};

	public static RowMapper<Complaint> COMPLAINT_MAPPER = new RowMapper<Complaint>() {
		@Override
		public Complaint mapRow(ResultSet resultSet, int rowNum) throws SQLException {
			return new Complaint(resultSet.getInt("complaint_id"), resultSet.getString("from_user"), resultSet.getString("against_user"), resultSet.getString("car_number"), ComplaintStatus.valueOf(resultSet.getString("complaint_status")), resultSet.getFloat("complaint_charges"), resultSet.getDate("upd_time"), null);
		}
	};
			

	public static RowMapper<Parking> PARKING_MAPPER = new RowMapper<Parking>() {
		@Override
		public Parking mapRow(ResultSet resultSet, int rowNum) throws SQLException {
			return new Parking(resultSet.getInt("parking_id"), ParkingType.valueOf(resultSet.getString("parking_type")), resultSet.getString("parking_number"), ParkingStatus.valueOf(resultSet.getString("parking_status")), resultSet.getFloat("price"), resultSet.getDate("upd_time"));
		}
	};

	public static RowMapper<AccessRequest> ACCESS_REQUEST_MAPPER = new RowMapper<AccessRequest>() {

		@Override
		public AccessRequest mapRow(ResultSet resultSet, int rowNum) throws SQLException {
			return new AccessRequest(resultSet.getInt("request_id"), 
					resultSet.getString("username"), 
					resultSet.getString("email"), 
					resultSet.getString("password"),
					resultSet.getString("apartment"), 
					resultSet.getInt("contact"),
					Status.valueOf(resultSet.getString("status")), 
					resultSet.getDate("upd_time"));
		}
	};

	public static RowMapper<RegisterRequest> REGISTER_REQUEST_MAPPER = new RowMapper<RegisterRequest>() {

		@Override
		public RegisterRequest mapRow(ResultSet resultSet, int rowNum) throws SQLException {
			return new RegisterRequest(resultSet.getInt("request_id"), resultSet.getString("email"), resultSet.getString("apartment_number"), resultSet.getString("car_number"), resultSet.getString("parking_number"), Status.valueOf(resultSet.getString("status")), resultSet.getDate("upd_time"));		}
	};
	
	public static RowMapper<Integer> USER_ID_MAPPER = getIdMapper("user_id");

	public static RowMapper<Integer> APARTMENT_ID_MAPPER = getIdMapper("apartment_id");

	public static RowMapper<Integer> PARKING_ID_MAPPER = getIdMapper("parking_id");

	public static RowMapper<Integer> ACCESS_REQUEST_ID_MAPPER = getIdMapper("request_id");

	public static RowMapper<Integer> COMPLAINT_ID_MAPPER = getIdMapper("complaint_id");
	
	public static RowMapper<Car> CAR_MAPPER = new RowMapper<Car>() {
		@Override
		public Car mapRow(ResultSet resultSet, int rowNum) throws SQLException {
			return new Car(resultSet.getInt("car_id"), resultSet.getString("car_number"), null);
		}
	};

	public static RowMapper<String> CAR_OWNER_MAPPER = new RowMapper<String>() {
		@Override
		public String mapRow(ResultSet resultSet, int rowNum) throws SQLException {
			return resultSet.getString("email");
		}
	};

	public static RowMapper<Integer> getIdMapper(String idColumnName) {
		return new RowMapper<Integer>() {
			@Override
			public Integer mapRow(ResultSet resultSet, int rowNum) throws SQLException {
				return resultSet.getInt(idColumnName);
			}
		};
	}
}
