package com.parking.dao;

import java.util.Date;
import java.util.List;

import org.apache.commons.codec.digest.DigestUtils;

import com.parking.domain.AccessRequest;
import com.parking.domain.Apartment;
import com.parking.domain.Car;
import com.parking.domain.Complaint;
import com.parking.domain.Parking;
import com.parking.domain.RegisterRequest;
import com.parking.domain.User;

public class ParkingHome extends AbstractMySqlHome {

	private SequenceSeedHome sequenceSeedHome;

	private static final Date UPD_TIME_END = new Date(1000, 0, 0);

	public ParkingHome (String host, String port, String database, String user, String password) {
		super (host, port, database, user, password);
		sequenceSeedHome = SequenceSeedHome.getInstance(host, port, database, user, password);
	}

	public boolean isValidUser(String email, String password) {
		if (email == null || password == null) {
			return false;
		}
		String dbPassword = RowMappers.mapFirstRow(executeQuery("SELECT password FROM user WHERE email=?", email), RowMappers.USER_PASSWORD_MAPPER);
		return dbPassword != null && getMD5Hash(password).equals(dbPassword);
	}

	public void persistAccessRequest(AccessRequest accessRequest) {
		if (accessRequest.getRequestId() == 0) {
			accessRequest.setRequestId(sequenceSeedHome.getAccessRequestSeed());
		} else {
			executeUpdate("UPDATE access_request SET upd_time_end=? WHERE request_id=? AND upd_time_end=?", accessRequest.getRequestDate(), accessRequest.getRequestId(), UPD_TIME_END);
		}
		executeUpdate("INSERT INTO access_request values(?, ?, ?, ?, ?, ?, ?, ?, ?)", 
				accessRequest.getRequestId(),
				accessRequest.getUserName(),
				accessRequest.getEmail(),
				getMD5Hash(accessRequest.getPassword()),
				accessRequest.getApartmentNumber(), 
				accessRequest.getContact(),
				accessRequest.getStatus().name(), 
				accessRequest.getRequestDate(), 
				UPD_TIME_END);
	}

	public void persistUser(User user) {
		if (user.getUserId() == 0) {
			user.setUserId(sequenceSeedHome.getUserSeed());
		} else {
			executeUpdate("UPDATE user SET upd_time_end=? WHERE user_id=? AND upd_time_end=?", new Date(), user.getUserId(), UPD_TIME_END);
		}
		executeUpdate("INSERT INTO user values(?, ?, ?, ?, ?, ?, ?, ?)", user.getUserId(), user.getName(), user.getEmail(), user.getUserRole().name(), user.getPassword(), user.getContact(), new Date(), UPD_TIME_END);
	}

	public void persistCar(Car car) {
		if (car.getCarId() == 0) {
			car.setCarId(sequenceSeedHome.getCarSeed());
		} else {
			executeUpdate("UPDATE car SET upd_time_end=? WHERE car_id=? AND upd_time_end=?", new Date(), car.getCarId(), UPD_TIME_END);
		}
		executeUpdate("INSERT INTO car values(?, ?, ?, ?, ?)", 
				car.getCarId(), 
				car.getCarNumber(), 
				car.getOwner(), 
				new Date(), 
				UPD_TIME_END);
	}
	
	public void persistUserApartment(int userId, int apartmentId, Date now) {
		executeUpdate("UPDATE user_apartment SET upd_time_end=? WHERE apartment_id=? AND upd_time_end=?", now, apartmentId, UPD_TIME_END);
		executeUpdate("INSERT INTO user_apartment values(?, ?, ?, ?)", userId, apartmentId, now, UPD_TIME_END);
	}

	public void persistApartmentParking(String apartmentNumber, String parkingNumber, Date now) {
		int apartmentId = getId("apartment", "apartment_id", "apartment_number", apartmentNumber);
		int parkingId = getId("parking", "parking_id", "parking_number", parkingNumber);
		executeUpdate("UPDATE apartment_parking SET upd_time_end=? WHERE parking_id=? AND upd_time_end=?", now, parkingId, UPD_TIME_END);
		executeUpdate("INSERT INTO apartment_parking values(?, ?, ?, ?)", apartmentId, parkingId, now, UPD_TIME_END);
	}

	public Apartment fetchApartment(String apartmentNumber) {
		Apartment apartment = new Apartment();
		apartment.setApartmentNumber(apartmentNumber);
		apartment.setApartmentId(getId("apartment", "apartment_id", "apartment_number", apartmentNumber));
		return apartment;
	}

	public void persistRegisterRequest(RegisterRequest registerRequest) {
		if (registerRequest.getRequestId() == 0) {
			registerRequest.setRequestId(sequenceSeedHome.getRegisterRequestSeed());
		} else {
			executeUpdate("UPDATE register_request SET upd_time_end=? WHERE request_id=? AND upd_time_end=?", registerRequest.getUpdateTime(), registerRequest.getRequestId(), UPD_TIME_END);
		}
		int apartmentId = getId("apartment", "apartment_id", "apartment_number", registerRequest.getApartmentNumber());
		int carId = getId("car", "car_id", "car_number", registerRequest.getCarNumber());
		int parkingId = getId("parking", "parking_id", "parking_number", registerRequest.getParkingNumber());
		int userId = getId("user", "user_id", "email", registerRequest.getUserEmail());
		executeUpdate("INSERT INTO register_request values(?, ?, ?, ?, ?, ?, ?)", registerRequest.getRequestId(), userId, apartmentId, registerRequest.getStatus().name(), carId, parkingId, registerRequest.getUpdateTime(), UPD_TIME_END);
	}

	public void persistComplaint(Complaint complaint) {
		if (complaint.getComplaintId() == 0) {
			complaint.setComplaintId(sequenceSeedHome.getComplaintSeed());
		} else {
			executeUpdate("UPDATE complaint SET upd_time_end=? WHERE complaint_id=? AND upd_time_end=?", complaint.getUpdateTime(), complaint.getComplaintId(), UPD_TIME_END);
		}
		
		int userFrom = getId("user", "user_id", "email", complaint.getComplaintFrom());
		int userTo = getId("user", "user_id", "email", complaint.getComplaintAgainst());
		int carId = getId("car", "car_id", "car_number", complaint.getCarNumber());
		
		executeUpdate("INSERT INTO complaint values(?, ?, ?, ?, ?, ?, ?,?)", complaint.getComplaintId(), userFrom, userTo , carId, complaint.getComplaintStatus(), 
				 complaint.getComplaintCharges(), complaint.getUpdateTime(), UPD_TIME_END);

	}

	public List<Car> fetchUserCars(int userId) {
		return RowMappers.mapAllRows(executeQuery("SELECT * FROM car WHERE car_owner=?", userId), RowMappers.CAR_MAPPER);
	}
	
	public Parking fetchParking(String parkingNumber) {
		return RowMappers.mapFirstRow(executeQuery("SELECT * FROM parking WHERE parking_number=? AND upd_time_end=?", parkingNumber, UPD_TIME_END), RowMappers.PARKING_MAPPER);
	}
	
	public List<Parking> fetchAvailableParkingSlots() {
		return RowMappers.mapAllRows(executeQuery("SELECT * FROM parking WHERE parking_status=? AND upd_time_end=?", "AVAILABLE", UPD_TIME_END), RowMappers.PARKING_MAPPER);
		
	}

	public List<AccessRequest> fetchAccessRequest(int userId) {
		return RowMappers.mapAllRows(executeQuery("select * from access_request where email=? and upd_time_end=?", userId, UPD_TIME_END), RowMappers.ACCESS_REQUEST_MAPPER);
	}
	
	public List<AccessRequest> fetchPendingAccessRequests() {
		return RowMappers.mapAllRows(executeQuery("select * from access_request where status=? and upd_time_end=?", "PENDING", UPD_TIME_END), RowMappers.ACCESS_REQUEST_MAPPER);
	}
	
	public AccessRequest fetchPendingAccessRequest(Integer requestId) {
		return RowMappers.mapFirstRow(executeQuery("select * from access_request where request_id=? and upd_time_end=?", requestId, UPD_TIME_END), RowMappers.ACCESS_REQUEST_MAPPER);
	}
	
	public List<RegisterRequest> fetchPendingRegisterRequests() {
		return RowMappers.mapAllRows(executeQuery("select * from register_request where status=? and upd_time_end=?", "PENDIN", UPD_TIME_END), RowMappers.REGISTER_REQUEST_MAPPER);
	}
	
	public RegisterRequest fetchPendingRegisterRequest(int requestId) {
		return RowMappers.mapFirstRow(executeQuery("SELECT * from register_request WHERE req.user_id=? and req.upd_time_end=?", requestId, UPD_TIME_END), RowMappers.REGISTER_REQUEST_MAPPER);
	}

	public List<RegisterRequest> fetchRegisterRequest(int userId) {
		return RowMappers.mapAllRows(executeQuery("SELECT * from register_request as req join user u1 on req.user_id = u1.user_id join apartment a1 on req.apartment_id = a1.apartment_id join car c1 on req.car_id = c1.car_id join parking p1 on p1.parking_id = req.parking_id where req.user_id=? and req.upd_time_end=?", userId, UPD_TIME_END), RowMappers.REGISTER_REQUEST_MAPPER);
	}

	public String fetchCarOwner(String carNumber) {
		return RowMappers.mapFirstRow(executeQuery("SELECT email from car join user on userId = owner where car_number = ? ", carNumber), RowMappers.CAR_OWNER_MAPPER);
	}

	public List<Complaint> getUserComplaints(int userId) {
		return RowMappers.mapAllRows(executeQuery(
				"SELECT comp.complaint_id, u1.email as from_user, u2.email as against_user, c1.car_number, comp.complaint_status, "
				+ "comp.complaint_charges, comp.upd_time from complaint comp join user u1 on comp.user_from = u1.user_id join user "
				+ "u2 on comp.user_to = u2.user_id join car c1 on comp.car_id=c1.car_id WHERE (u1.user_id=? OR u2.user_id=?) and comp.upd_time_end=?",
				userId, userId, UPD_TIME_END), RowMappers.COMPLAINT_MAPPER);
	}

	public List<Apartment> getUserApartments(int userId) {
		return null;
//		return RowMappers.mapAllRows(executeQuery("SELECT apt.* FROM apartment WHERE user_id=?", userId), RowMappers.USER_WITHOUT_PASSWORD_MAPPER).get(0);
	}

	public User getUser(String email) {
		return RowMappers.mapFirstRow(executeQuery("SELECT * FROM user WHERE email=?", email), RowMappers.USER_WITHOUT_PASSWORD_MAPPER);
	}

	public void populateUserDetails(User userId) {
	}

	private static String getMD5Hash(String password) {
		return DigestUtils.md5Hex(password).toUpperCase();
	}

	private int getId(String tableName, String idColumnName, String auxColumnName, Object auxColumnValue) {
		return RowMappers.mapFirstRow(executeQuery("SELECT " + idColumnName + " FROM " + tableName + " where " + auxColumnName + "=? and upd_time_end=?", auxColumnValue, UPD_TIME_END), RowMappers.getIdMapper(idColumnName));
	}
}
