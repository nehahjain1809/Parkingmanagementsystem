package com.parking;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.parking.dao.ParkingHome;
import com.parking.domain.Car;
import com.parking.domain.Complaint;
import com.parking.domain.ComplaintStatus;
import com.parking.domain.Parking;
import com.parking.domain.RegisterRequest;
import com.parking.domain.Status;

@Controller
@RequestMapping(value="/resident/*")
public class ResidentController {
	
	@Resource
	private ParkingHome parkingHome;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		return "user-dashboard";
	}
	
	@RequestMapping(value="action/register", method = RequestMethod.GET)
	public String handleRegisterVehicleForm(HttpServletRequest request) {
		HttpSession session = request.getSession();
		String userId = session.getAttribute("userid").toString();
		List<Car> userCars = parkingHome.fetchUserCars(Integer.parseInt(userId));
		List<Parking> parkingslots = parkingHome.fetchAvailableParkingSlots();
		List<Parking> parkingbasementslots = new ArrayList<Parking>();
		List<Parking> parkinggarageslots = new ArrayList<Parking>();
		List<Parking> parkingopenslots = new ArrayList<Parking>();
		
		for(Parking parking: parkingslots) {
			if(parking.getParkingType().equals("BASEMENT")) {
				parkingbasementslots.add(parking);
			}
			else if (parking.getParkingType().equals("GARAGE")) {
				parkinggarageslots.add(parking);
			}
			else{
				parkingopenslots.add(parking);
			}
		}
		request.setAttribute("parkingbasementslots", parkingbasementslots);
		request.setAttribute("parkinggarageslots", parkinggarageslots);
		request.setAttribute("parkingopenslots", parkingopenslots);
		request.setAttribute("userCars", userCars);
		
		return "register-vehicle";
	}
	
	@RequestMapping(value="action/complaint", method = RequestMethod.GET)
	public String handleGetFileComplaintForm(HttpServletRequest request) {
		
		return "file-complaint";
	}
	
	@RequestMapping(value="action/guest", method = RequestMethod.GET)
	public String handleGuestServicesForm(HttpServletRequest request) {
		
		
		return "guest-services";
	}
	
	@RequestMapping(value="action/register/mycar", method = RequestMethod.POST)
	public String handleCarRegisterRequestForm(HttpServletRequest request) {
		Car car = new Car(
				0,
				request.getParameter("carNumber"),
				request.getSession().getAttribute("userid").toString()
				);
		parkingHome.persistCar(car);
		return "register-vehicle";
	}
	
	@RequestMapping(value="action/register/parking", method = RequestMethod.POST)
	public String handleRaiseRegisterRequestForm(HttpServletRequest request) {
		RegisterRequest registerRequest = new RegisterRequest(
				0,
				(String) request.getParameter("email"),
				(String) request.getParameter("apartmentNumber"),
				(String) request.getParameter("usercars"),
				(String) request.getParameter("parkingNumber"),
				Status.PENDING, new Date());
		parkingHome.persistRegisterRequest(registerRequest);
		request.setAttribute("registerRequest", registerRequest);
		return "register-vehicle-success";
	}

	// Placeholder to get penalty depending on business logic
	private void populatePenalty(Complaint complaint) {
		complaint.setComplaintCharges(100F);
	}

	@RequestMapping(value="action/complaint/file", method = RequestMethod.POST)
	public String handleFileComplaintForm(HttpServletRequest request) {
		
		Parking parking = parkingHome.fetchParking(request.getParameter("parkingNumber"));
		
		
		Complaint complaint = new Complaint(0, request.getParameter("complaintFrom"), parkingHome.fetchCarOwner(request.getParameter("carNumber")),
				request.getParameter("carNumber"), ComplaintStatus.PENDING, 0F, new Date(), parking);
		populatePenalty(complaint);
		parkingHome.persistComplaint(complaint);
		request.setAttribute("complaint", complaint);
		return "file-complaint-sucess";
	}
}
