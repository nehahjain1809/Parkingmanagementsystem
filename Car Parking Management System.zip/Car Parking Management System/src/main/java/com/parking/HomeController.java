package com.parking;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.parking.dao.ParkingHome;
import com.parking.domain.AccessRequest;
import com.parking.domain.Status;
import com.parking.domain.User;
import com.parking.domain.Complaint;
import com.parking.domain.UserRole;


/**
 * Handles requests for the application home page.
 */
@Controller
@RequestMapping(value="/")
public class HomeController {

	@Resource
	private ParkingHome parkingHome;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		return "home";
	}
	
	
	@RequestMapping(value="/home/raiserequest", method = RequestMethod.POST)
	public String handleRaiseAccessRequestForm(HttpServletRequest request) {
		
		AccessRequest accessRequest = new AccessRequest
				(0, 
				(String) request.getParameter("name"), 
				(String) request.getParameter("email"), 
				(String) request.getParameter("password"),
				(String) request.getParameter("apartment"), 
				Integer.parseInt(request.getParameter("contact")),
				Status.PENDING, 
				new Date());
		parkingHome.persistAccessRequest(accessRequest);
		request.setAttribute("accessRequestId", accessRequest.getRequestId());
		return "access-request-success";
	}

	
	@RequestMapping(value="/home/login", method = RequestMethod.POST)
	public String handleLoginForm(HttpServletRequest request) {
		String email = request.getParameter("username");
		if (!parkingHome.isValidUser(email, request.getParameter("pwd"))) {
			request.setAttribute("message", "Username or password is incorrect");
			return "home";
		}
		
		User user = parkingHome.getUser(email);
		HttpSession session = request.getSession();
		if (user.getUserRole() ==  UserRole.ADMIN) {
			
			session.setAttribute("useremail", user.getEmail());
			session.setAttribute("userid", user.getUserId());
			return "admin-dashboard";
		} else if (user.getUserRole() == UserRole.APARTMENT_OWNER) {
				
			// retrieve user complaints, access-requests and register-requests for user dash-board

			// retrieve user complaints
			List<Complaint> complaintsFrom = new ArrayList<>();
			List<Complaint> complaintsAgainst = new ArrayList<>();
			for (Complaint complaint : parkingHome.getUserComplaints(user.getUserId())) {
				if (email.equals(complaint.getComplaintFrom())) {
					complaintsFrom.add(complaint);
				} else {
					complaintsAgainst.add(complaint);
				}
			}
			request.setAttribute("complaintsFrom", complaintsFrom);
			request.setAttribute("complaintsAgainst", complaintsAgainst);

			// retrieve access-requests
			request.setAttribute("accessRequests", parkingHome.fetchAccessRequest(user.getUserId()));

			// retrieve register-requests
			request.setAttribute("registerRequests", parkingHome.fetchRegisterRequest(user.getUserId()));
			session.setAttribute("useremail", user.getEmail());
			session.setAttribute("userid", user.getUserId());
			return "user-dashboard";
		}
		return "internal-exception";
	}
		
}


